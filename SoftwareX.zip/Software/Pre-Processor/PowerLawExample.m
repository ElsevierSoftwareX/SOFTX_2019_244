% ==========================================================================
% PowerLaw.m - Fit the FGM properties with power law variation using a
% B-Spline curve
% ==========================================================================
% Created:     30-Mar-2019   Evandro Parente Junior
%
% Modified:
% ==========================================================================

clc;
clear;

% Mechanical properties.

E_mat = 74;   
E_inc = 429; 
nu_mat = 0.33;
nu_inc = 0.17;

% Generate ficticious experimental data using a power law distribution.

N  = 0.4;                       % Volume fraction exponent
nd = 21;                        % Number of data points
t  = linspace(0, 1, nd);        % Parametric coordinate
Vm = t.^N;                      % Volume fraction

% Call MicroFEA pre-processor.

np = 41;                        % Number of points for ploting results
PrepMicroFEA(E_mat, E_inc, nu_mat, nu_inc, t, Vm, np, 'Mori-Tanaka');


