% -------------------------------------------------------------------------
%       Returns the Eshelby Tensor for a spheroidal inclusion.
%       Equations obtained from:
%       "Micromechanics of defects in solids", Toshio Mura, 1987
%       ISBN: 978-90-247-3256-2
%       DOI: 10.1007/978-94-009-3489-4
%
%                     Written by Marcelo S. Medeiros Jr.
%                            September 20th 2017
% -------------------------------------------------------------------------


function [S] = Eshelby_Sphere(v0)


S = zeros([6 6]);

%  ---------------------- Equations 11.21 Page 79 --------------------------

for i=1:3
  for j=1:3
    if (i == j) 
	  S(i,j) = (7-5*v0)/(15*(1-v0));
	  S(i+3, j+3) = (4-5*v0)/(15*(1-v0));
	else
	  S(i,j) = (5*v0-1)/(15*(1-v0));
	end
  end
end

end

