% =========================================================================
% PrepMicroFEA.m - MicroFEA pre-processor.
% =========================================================================
% FitBSpline1D - Fit a B-Spline curve to a set of 1D points.
%
% bsp = FitBSpline1D(t, f, n, p) fit a B-Spline curve to set of given data 
% points (t, f):
%   
%   t   - parametric coordinates of data points                       (in)
%   f   - function values of data points, i.e. f(t)                   (in)
%   n   - number of control points                                    (in)
%   p   - basis degree                                                (in)
%   bsp - struct with B-spline data (n, p, knot, ctrl)                (out)      
%
% See also: EvalBSpline1D, basisfun, findspan

% =========================================================================
%
%  Copyright (C) 2018  Marcelo S. Medeiros Jr. and Evandro Parente Jr.
%
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%
%  You should have received a copy of the GNU General Public License
%  along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
% =========================================================================
% Created:     Dec-10-2018   
%
% Modified:
% =========================================================================

function PrepMicroFEA(E_mat, E_inc, nu_mat, nu_inc, t, Vm, np, micro)

  % Fit a B-Spline to the given data.

  n = 10;                         % Number of control points
  p = 3;                          % Basis degree
  Vmbsp = FitBSpline1D(t, Vm, n, p) % B-Spline fit

  % Plot the experimental data and the fitted curve.
  
  ts = linspace(min(t), max(t), np);
  Vms = EvalBSpline1D(Vmbsp, ts);
  subplot(1, 3, 1);
  plot(t, Vm, 's', ts, Vms, '-');
  xlabel('t');
  ylabel('Vm');
  legend('Data', 'B-Spline', 'Location', 'Best');
  grid on;

  % Evaluate the FGM properties using the Mori-Tanaka method.

  H = Eshelby_Sphere(nu_mat);
  C_mat = Isotropic_Stiffness(E_mat, nu_mat);
  C_inc = Isotropic_Stiffness(E_inc, nu_inc);
  nd = length(t);
  E  = zeros(1, nd);
  nu = zeros(1, nd);
  for i = 1:nd
    if (strcmp(micro, 'Mori-Tanaka'))
      C = Mori_Tanaka(C_mat, C_inc, Vm(i), H);
    elseif (strcmp(micro, 'Christensen'))       
      C = Christensen(C_mat, C_inc, Vm(i));
    elseif (strcmp(micro, 'Self_Consistent'))         
      C = Self_Consistent(C_mat, C_inc, Vm(i), H);
    elseif (strcmp(micro, 'Reuss')) 
      C = Reuss(C_mat, C_inc, Vm(i));
    else        
      C = Voigt(C_mat, C_inc, Vm(i));
    end  
    S = inv(C);
    E(i)  = 1/S(1,1);
    nu(i) = -E(i)*S(1,2);
  end

  % Fit the elastic modulus variation using a B-Spline curve.

  Ebsp = FitBSpline1D(t, E, n, p);
  Es = EvalBSpline1D(Ebsp, ts);
  subplot(1, 3, 2);
  plot(t, E, 's', ts, Es, '-');
  xlabel('t');
  ylabel('E');
  legend('Data', 'B-Spline', 'Location', 'Best');
  grid on;

  % Fit the Poisson's ratio variation using a B-Spline curve.

  nubsp = FitBSpline1D(t, nu, n, p);
  nus = EvalBSpline1D(nubsp, ts);
  subplot(1, 3, 3);
  plot(t, nu, 's', ts, nus, '-');
  xlabel('t');
  ylabel('nu');
  legend('Data', 'B-Spline', 'Location', 'Best');
  grid on;

  % Save data to the Abaqus .inp file.
  
%  fid = fopen(filename);
%  y = 0;
%  tline = fgetl(fid);
%  while ischar(tline)
%    matches = strfind(tline, literal);
%    num = length(matches);
%    if num > 0
%       y = y + num;
%       fprintf(1,'%d:%s\n',num,tline);
%    end
%    tline = fgetl(fid);
%  end
% fclose(fid); 

  fid = fopen('MicroFEAv1.0.txt', 'w');
  nk = n + p + 1;
  nc = nk + 2*n;
  fprintf(fid, '*User Material, constants=%d\n', nc);
  for i = 1:nk-1
    fprintf(fid, '%0.5f,  ', Ebsp.knot(i));
  end
  fprintf(fid, '%0.5f\n', Ebsp.knot(nk));
  for i = 1:n
    fprintf(fid, '%0.5e,  ', Ebsp.ctrl(i));
  end
  fprintf(fid, '%0.5e\n', Ebsp.ctrl(n));
  for i = 1:n
    fprintf(fid, '%0.5f,  ', nubsp.ctrl(i));
  end
  fprintf(fid, '%0.5f\n', nubsp.ctrl(n));
  fclose(fid);
end
