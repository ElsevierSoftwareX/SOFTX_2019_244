function [S] = Eshelby_Cylinder(a1, a2, v)
% Returns the Interior Elsheby Tensor of an Elliptic Cylindrical
% Inclusion in Voigt contracted notation. 
% Equations from "Fracture Mechanics with an Introduction to
% Micromechanics", Dietmar Gross, 2nd Edition, page 235, Equation 8.9;
   
S = zeros ([6 6]);
c1 = 1/(2*(1-v));
c2 = 1-2*v;
a3 = a1 + a2;

% ---- S1111 ----
S(1,1) = c1*(((a2^2+(2*a1*a2))/a3^2)+ (c2*(a2/a3)));

% ---- S1122 ----
S(1,2) = c1*((a2^2/a3^2)-(c2*a2/a3));

% ---- S1133 ----
S(1,3) = v*c1*(2*a2/a3);

% ---- S2211 ----
S(2,1) = c1*(a1^2/a3^2 - (c2*a1/a3));

% ---- S2222 ----
S(2,2) = c1*(((a1^2+(2*a1*a2))/a3^2)+ (c2*(a1/a3)));

% ---- S2233 ----
S(2,3) = v*c1*(a1/a3);

% ---- S2323 ----
S(4,4) = a1/2*a3;

% ---- S1313 ----
S(5,5) = a2/2*a3;

% ---- S1212 ----
S(6,6) = c1*((a1^2+a2^2)/(2*(a3^2))+(c2/2));

end
