% Isotropic_Stiffness - Fit a B-Spline curve to a set of 1D points.
%
% [C] = Isotropic_Stiffness (E, nu) Returns the Elastic Isotropic Stiffness 
%  Matrix
%   
%   E   - Young's Modulus                                             (in)
%   nu  - Poisson's Ratio                                             (in)
%   C   - Isotropic Stiffness Matrix (6x6 matrix)                     (out)      
%

% =========================================================================
%
%  Copyright (C) 2018  Marcelo S. Medeiros Jr.
%
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%
%  You should have received a copy of the GNU General Public License
%  along with this program.  If not, see <http://www.gnu.org/licenses/>.
%
% =========================================================================
% Created:     16-Jan-2018   Marcelo S. Medeiros Jr.
%
% Modified:
% =========================================================================

function [C] = Isotropic_Stiffness (E, nu)

C = [1-nu,  nu,   nu,   0,    0,    0;
     nu,   1-nu,  nu,   0,    0,    0;
     nu,    nu,  1-nu,  0,    0,    0;
     0,     0,    0, 0.5-nu,  0,    0;
     0,     0,    0,    0, 0.5-nu,  0;
     0,     0,    0,    0,    0, 0.5-nu];
 
C = C*E/((1+nu)*(1-2*nu));
end