% -------------------------------------------------------------------------
%            Implementation of Mori-Tanaka Homogenization Scheme
%         As per "A New Approach to the Application of Mori-Tanaka's
%             Theory in Composite Materials", Y. Benveniste (1987)
%                     DOI: 10.1016/0167-6636(87)90005-6
%     Alternative Formulation from the Book "Fracture Mechanics with an
%            Introduction to Micromechanics" by Gross and Seeling.
%              Written by Marcelo Medeiros on February 3rd, 2018
% -------------------------------------------------------------------------

function [C_homo] = Mori_Tanaka (C_mat, C_inc, vf, ESh)

I = eye(6);   % Unit tensor

%  ------------  Strain concentration Tensor (Eq. 7a) ---------------------
MT = inv(I + ESh*inv(C_mat)*(C_inc - C_mat)); 

%MT = inv(I + (1-vf)*ESh*inv(C_mat)*(C_inc - C_mat));  % Alternative Eq.

% -------------------- Homogenized Moduli (Eq. 14a) ------------------------
C_homo = C_mat + vf*(C_inc - C_mat)*MT*inv((1-vf)*I+ vf*MT);

%C_homo = C_mat + vf*(C_inc - C_mat)*MT;    % Alternative Eq.

end