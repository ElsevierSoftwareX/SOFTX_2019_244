

function [C_homo] = Reuss (C_mat, C_inc, vf)

S_mat = C_mat^-1;
S_inc = C_inc^-1;

S_reuss = S_mat + vf*(S_inc - S_mat);
C_homo = S_reuss^-1;
end