

function [C_homo] = Voigt(C_mat, C_inc, vf)

C_homo = C_mat + vf*(C_inc - C_mat);

end