% -------------------------------------------------------------------------
%
%                 Self-Consistent Homogenization Scheme
%                             
%       Input: 
%              
%       Output: 
%
%           Written by Marcelo Medeiros, PhD on July 8th, 2018
%
% -------------------------------------------------------------------------

function [C_homo] = Self_Consistent(C_mat, C_inc, vf, ESh)


I = eye(6);     % Identity Matrix
C_homo = zeros([6,6]);

%  Use the Rule of Mixture as initial guess for composite stiffness matrix
C = vf*C_inc + (1 - vf)*C_mat;

S = inv(C);     % Compliance Matrix

diff = 10;


while diff > 0.005
    A = inv(I + ESh*S*(C_inc - C));
    C_homo = C_mat + (vf.*(C_inc - C_mat))*A;
    diff = abs(det(C) - det(C_homo));
   % norm(C)
   % norm(C_homo)
    C = C_homo;
end

end