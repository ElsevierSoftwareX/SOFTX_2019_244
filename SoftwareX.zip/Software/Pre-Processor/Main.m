
clear all;
E_mat = 74;
E_inc = 429;
nu_mat = 0.33;
nu_inc = 0.17;

% E_mat = 4.1;
% E_inc = 87.0;
% nu_mat = 0.35;
% nu_inc = 0.22;

% k_mat = E_mat/(3 - 6*nu_mat);
% g_mat = E_mat/(2+2*nu_mat);

%vf = linspace(0,1,51);
%x = linspace(0,1,51);

load('Data_Paper.mat');
%clear xx yy
%x = Exp_Data(:,1);
vf = yy;
%x = x_exp;

H = Eshelby_Sphere(nu_mat);
num = length(vf);
E = zeros(1,num);
nu = zeros(1,num);
%k = [];
%g = [];

C_0 = Isotropic_Stiffness(E_mat, nu_mat);
C_1 = Isotropic_Stiffness(E_inc, nu_inc);

for i=1: num
    %C = Self_Consistent(C_0, C_1, vf(i), H);
    C = Mori_Tanaka(C_0, C_1, vf(i), H);
    %C = Reuss (C_0, C_1, vf(i));
    %C = Voigt (C_0, C_1, vf(i));
    %C = Christensen (C_0, C_1, vf(i));
    S = inv(C);
    E(i) = 1/S(1,1);
    nu(i) = -E(i)*S(1,2);
    %k(i) = E(i)/(3 - 6*nu(i));
    %g(i) = E(i)/(2+2*nu(i));
end
x = xx;
plot(xx, E, '-k');
figure
plot(x, nu, '-b');
%hold on;
%plot(x,y, 'sb')
save('SoftwareX.mat', 'x', 'E', 'vf', 'nu');
%save('Mori_Tanaka', 'E', 'vf', 'nu');
%save('Voigt', 'E', 'vf', 'nu');

