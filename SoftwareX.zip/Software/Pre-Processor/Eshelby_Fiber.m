function [S] = Eshelby_Fiber(a, nu0)
%             Written by Marcelo S. Medeiros Jr.
%                   September 12th 2017
%
% Returns the Eshelby Tensor for a fiber-like ellipsoidal inclusion.
% Equations obtained from:
% "The Effect of Aspect Ratio of Inclusions on the Elastic Properties of
% Unidirectionally Aligned Composites", G. P. Tandon and G. J. Weng,
% Polymer Composites, Vol. 5, No. 4, 1984; DOI: 10.1002/pc.750050413
%
%   a = alpha = (length/diameter); nu0 = Poisson's Ratio of the Matrix

%  ------ Auxiliary Constants ---------
c1 = 1 - nu0;
c2 = a^2 - 1;
c3 = 1 - 2*nu0;
c4 = a^2 + 1;

% ------------------ Output Variable -------------------
S = zeros([6 6]);

% ----- g(a) -----
%g = (a/(c2^(3/2)))*(a*(c2^0.5) - cosh(a)^-1);
g = 1 - ((log(2*a)-1)/(a^2));

% ----------- Components of the Eshelby Tensor --------------

% ---- S1111 ----
S(1,1) = (1/(2*c1))*(c3+(((3*a^2)-1)/c2) - g*(c3+((3*a^2)/c2)));
%S(1,1)=1.777001554;

% ---- S2222 ----
%S1 = (3/(8*c1))*((a^2)/c2)+(1/(4*c1))*(c3-(9/(4*c2)))*g;
S(2,2) = (1/(4*c1))*(((3*a^2)/(2*c2)) + g*(c3-(9/(4*c2))));

% ---- S3333 ----
S(3,3) = S(2,2);

% ---- S2233 ----
S(2,3) = (1/(4*c1))*(((a^2)/(2*c2))-((c3+(3/(4*c2)))*g));

% ---- S3322 ----
S(3,2) = S(2,3);

% ---- S2211 ----
S(2,1) = (-1/(2*c1))*((a^2)/c2)+(1/(4*c1))*(((3*a^2)/c2)-c3)*g;

% ---- S3311 ----
S(3,1) = S(2,1);

% ---- S1122 ----
S(1,2) = (-1/(2*c1))*(c3+(1/c2))+((1/(2*c1))*(c3+(3/(2*c2)))*g);

% ---- S1133 ----
S(1,3) = S(1,2);

% ---- S2323 ----
S(4,4) = (1/(4*c1))*(((a^2)/(2*c2))+(c3 -(3/(4*c2)))*g);

% ---- S1212 ----
S(6,6) = (1/(4*c1))*(c3-(c4/c2)-0.5*(c3-(3*c4/c2))*g);
end
